

#include<stdio.h>

void getput();

int main()

{

   getput();

    return 0;
}

void getput()
{
   char name[256];
   //name[0]='\0';
    printf("your name:");
    gets(name);

      printf("your name is: \n");
      puts(name);

}
