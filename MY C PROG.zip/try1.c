

#include<stdio.h>

struct student
{

    int roll;
    char name[10];

};

int main()

{
    struct student std;

    printf("Enter Roll: \n");
    scanf("%d",&std.roll);
    printf("Enter Name: \n");
    scanf("%s",&std.name);


    printf("roll: %d, name: %s\n",std.roll,std.name);








}
