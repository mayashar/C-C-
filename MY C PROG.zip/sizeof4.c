#include<stdio.h>

int main() {
   int num = 3;
   printf("%d", sizeof(num));
   return 0;
}
