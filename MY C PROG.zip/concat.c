


#include <stdio.h>
#include <string.h>

void concat();

int main()
{
    concat();
    return 0;
}
void concat()
{
    printf("concating\n");



    char str1[20]="water";
    char str2[20]="melon";

    strcat(str1,str2);
    printf("result: %s\n",str1);
}
