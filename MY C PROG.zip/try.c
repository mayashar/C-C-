

#include<stdio.h>

struct student
{

    int roll;
    char name[10];

};

int main()

{
    struct student std;

    std.roll=1;
    sprintf(std.name,"tom");

    printf("roll: %d, name: %s\n",std.roll,std.name);

    std.roll=2;
    sprintf(std.name,"mom");


    printf("roll: %d, name: %s\n",std.roll,std.name);



}
