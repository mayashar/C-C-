#include<stdio.h>

void main() {
   int i = 1;
   printf("%d %d %d",i,++i,i++);



}
