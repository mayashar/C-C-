#include<stdio.h>
int main()
{
int num1 = 30;
int num2 = 40;
printf("Value of %d > %d is %d",    num1,num2,num1> num2);
printf("\nValue of %d >=%d is %d",	num1,num2,num1>=num2);
printf("\nValue of %d <=%d is %d",	num1,num2,num1<=num2);
printf("\nValue of %d < %d is %d",	num1,num2,num1< num2);
return(0);
}
