#include<stdio.h>

int main()
{
typedef int Roll;
Roll num1 = 40,num2 = 20;

printf("Roll number 1 : %d",num1);
printf("\nRoll number 2 : %d",num2);
return(0);
}
