

#include <stdio.h>
int main()
{
   int n;
   FILE *fptr;
   fptr=fopen("demo.txt","w");
   if(fptr==NULL){
      printf("Error!");
      exit(1);
   }
   printf("Enter n: ");
   scanf("%d",&n);
   fprintf(fptr,"%d",n);
   fclose(fptr);
   return 0;
}
