#include<stdio.h>
int main()
{
    int num1 = 30;
    int num2 = 20;
    int tot=40;

    if(num1>=40 || num2>=40)
        printf("you are passed ");

    if(num1>=40 && num2>=40)
        printf("\nPassed");

    if( !(num1>=40))
        printf("\nFailed");

    return(0);
}
