#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	int row,column;

	//srand((unsigned)time(NULL));

	for(row=1;row<6;row++)
	/*{
		for(column=1;column<6;column++)
			printf("%2d\t" );
		putchar('\n');
	}*/

	return(0);
}
