//formatted printing
              
#include<stdio.h>



int main(void)
{
    int i,j;
    float x,y;
    
    i=3;
    j=6;
    x=6.87658f;
    y=9.7653f;
    
    printf("i=%d,j=%d,x=%f,y=%f",i,j,x,y);
    
    
    getch();
    
    
    
    }
