//Compute a universal product code check digit:
              
#include<stdio.h>



int main(void)
{
    int d, i1, i2, i3, i4, i5, j1, j2, j3, j4, j5, first_sum, sec_sum, total;
    
    
    printf("Enter the first (single) digit:  ");
    scanf("%d",  &d);
    
    printf("Enter the first group of five digit:  ");
    scanf("%d %d %d %d %d",  &i1, &i2, &i3, &i4, &i5);
    
    printf("Enter the second group of five digit:  ");
    scanf("%d %d %d %d %d",  &j1, &j2, &j3, &j4, &j5);
    
    
    first_sum=d+i2+i4+j1+j3+j5;
    
    sec_sum=i1+i3+i5+j2+j4;
    
    total=3*first_sum+sec_sum;
    
    printf("Check digit:  %d\n", 9- ((total-1) % 10));    
    
    
    getch();
    
    
    
    }
