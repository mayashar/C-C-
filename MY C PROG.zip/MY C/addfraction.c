//Adding Fraction
              
#include<stdio.h>



int main(void)
{
    int num1,denum1, num2, denum2,resnum,resdenum;
    
    printf("Enter First Fraction: ");
    scanf("%d/%d",&num1,&denum1);
    
    
    printf("Enter Second Fraction: ");
    scanf("%d/%d",&num2,&denum2);
    
    resnum=num1*denum2+num2*denum1;
    
    resdenum=denum1*denum2;
    
    printf("The Sum Of This Fraction is : %d/%d\n",resnum,resdenum);
    
    getch();
    
    
    
    }
