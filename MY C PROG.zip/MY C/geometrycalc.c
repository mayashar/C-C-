//Program For Geometric calculation

//Area of rectangle

#include<stdio.h>


int main(void)
{

   int l,b,rectarea;
   printf("Enter Length: ");
   scanf("%d", &l);
   printf("Enter Breadth: ");
   scanf("%d",&b);
   rectarea=l*b;
   
   printf("The Area of Rectangle is %d:\n", rectarea);
   
//Area of Square
       int x,areasq;
       printf("Enter value of a side of square: ");
       scanf("%d",&x);
       areasq=x*x;
   
   printf("The Area of Square is %d:", areasq);
   

  
  
  
   getch();
    
    
    }
