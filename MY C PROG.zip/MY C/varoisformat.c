//Print int and float in various format:
              
#include<stdio.h>



int main(void)
{
    int i;
    float x;
    
    i=40;
    x=876.39f;
    
    printf("|%d|%5d|%-5d|%5.3d|\n",i,i,i,i);
    printf("|%f|%10.3f|%10.3e|%-10g|\a",x,x,x);
    
    
    getch();
    
    
    
    }
