//If statement:
              
#include<stdio.h>



int main(void)

{
    int Markobt,total;
    total=800;
    
    printf("Enter Marks Obtained: ");
    scanf("%d", &Markobt);
    
    if (Markobt>800){
                     
                     printf("Sorry Its an ERROR!!!");
                     
                     }
    else 
    if (Markobt>600 ){
                     
                     printf("FIRST!!!");
                     
                     }
    else 
    if (Markobt<300){
                     
                     printf("Sorry FAILED!!!");
                     
                     }
                     
    else{
         printf("PASSED");
         }
    getch();
    
    
    
    }
