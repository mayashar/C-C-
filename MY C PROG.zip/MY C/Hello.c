// A Simple Print To Begin C

#include<stdio.h>



int main(void)
{
    
   printf ("Hello world"); 
    
    getch();
    
    }
