#include<stdio.h>
#define M 50

struct student {
   char name[50];
   int roll;
   int total;
} st[M]; /* array of structure */

int main() {
   int i, n, mn, mt, maxstd, maxtot;

   mn = mt= 0;
   maximumLiteracyRate = maximumIncome = 0;

   printf("Enter how many students:");
   scanf("%d", &n);

   for (i = 0; i < n; i++) {
      printf("\nEnter student %d details :", i);

      printf("\nEnter  name : ");
      scanf("%s", &st[i].name);

      printf("\nEnter total roll : ");
      scanf("%d", &st[i].);

      printf("\nEnter total literary rate : ");
      scanf("%f", &rate);
      st[i].literacyRate = rate;

      printf("\nEnter total income : ");
      scanf("%f", &st[i].income);
   }

   for (i = 0; i < n; i++) {
      if (st[i].literacyRate >= maximumLiteracyRate) {
         maximumLiteracyRate = st[i].literacyRate;
         ml++;
      }
      if (st[i].income > maximumIncome) {
         maximumIncome = st[i].income;
         mi++;
      }
   }

   printf("\nState with highest literary rate :%s", st[ml].name);
   printf("\nState with highest income :%s", st[mi].name);

   return (0);
}
