#include<stdio.h>

void main()
{
int a,b;

a = 10;
b = 10;

printf("Value of a : %d",++a);
printf("\nValue of b : %d",b++);
}
