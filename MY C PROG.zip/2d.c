#include<stdio.h>

int main() {
   int i, j;
   int a[5][3] = { { 5, 4,2},
                 { 5, 2 ,7},
                 { 6, 5,8 },
                 { 2, 4,1 },
                 { 3, 1 ,3}

                 };

   for (i = 0; i < 5; i++) {
      for (j = 0; j < 5; j++) {
         printf("%d ", a[i][j]);
      }
      printf("\n");
   }
   return 0;

}
