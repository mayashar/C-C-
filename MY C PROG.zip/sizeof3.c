#include<stdio.h>

int main() {

   printf("%d", sizeof(10));
   printf("%d", sizeof('A'));
   printf("%d", sizeof(10.10));

   return 0;
}
