#include<stdio.h>

int main()
{
printf("Hello\tmaya\t\nhow are you?\n");
printf("H\bello\n");
printf("Hell\bo\n");
printf("He\rllo\n");
printf("Hello\a\n");
printf("Hel\vlo");



return(0);
}
