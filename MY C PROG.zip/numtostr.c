#include<stdio.h>
#include<string.h>
void numtostr();

int main()
{
    numtostr();
    return 0;
}

void numtostr()
{
    printf("number to string:\n");

    int n=10;
    float m=12.960878;

    char num1[10];
    char num2[10];

   sprintf(num1,"%d",n);
    sprintf(num2,"%.2f",m);

    printf("num1: %s\n",num1);
    printf("num2: %s\n",num2);
}
