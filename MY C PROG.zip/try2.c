

#include<stdio.h>

struct student
{

    int roll;
    char name[10];

};

int main()

{
    int numbers[5];
    char chars[10];
    struct student list[5];

    int i;
    for(i=0;i<5;i++)
    {
        numbers[i]=i;

        list[i].roll=i;
        sprintf(list[i].name,"maya %d",i);



    }

    sprintf(chars,"ABCDE");

    for(i=0;i<5;i++)

    {

        printf("%d %c\n",numbers[i],chars[i]);

        printf("struct.roll: %d, name: %s\n",list[i].roll,list[i].name);


    }

    printf("%s\n",chars);

      return 0;


}










