

#include<stdio.h>

void getput();

int main()

{

   getput();

    return 0;
}

void getput()
{
    int c;
    printf("type a character:");
    c=gets();
    printf("the character is: %c\n",c);
    putchar(c);
    printf("\n");
}
