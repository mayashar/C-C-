

#include<stdio.h>

int main()

{

    int matrix[3][5];

    int i,j;
    for(i=0;i<3;i++)

    {
        for(j=0;j<5;j++)

        {
            matrix[i][j]=i+j;

        }

    }

    for(i=0;i<3;i++)

    {
        for(j=0;j<5;j++)

        {
            printf("%d",matrix[i][j]);

        }

    printf("\n");

    }

    return 0;
}
