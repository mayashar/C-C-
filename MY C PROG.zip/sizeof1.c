int main() {

   int ivar = 2;
   char cvar = 'a';
   float fvar = 10.10;

   printf("%d", sizeof(ivar));
   printf("%d", sizeof(cvar));
   printf("%d", sizeof(fvar));
   return 0;
}
