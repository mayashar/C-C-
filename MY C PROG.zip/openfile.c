#include <stdio.h>
int main()
{
   int n;
   FILE *fptr;
   fptr=fopen("demo.txt","a");
   if(fptr==NULL){
      printf("Error!");
      exit(1);
   }

   return 0;
}
