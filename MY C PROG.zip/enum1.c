

#include<stdio.h>


void main()
{
int i;
enum month {JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,DEC};

  for(i=JAN;i<=DEC;i++)
      printf("\n%d",i);


printf("\n\ndays of week\n");


int x;
enum day {SUN,MON, TUE, WED, THURS, FRI, SAT};

  for(x=SUN;x<=SAT;x++)
      printf("\n%d",x);
}

