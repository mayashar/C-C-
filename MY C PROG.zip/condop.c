#include<stdio.h>

int main()
{
int num;

printf("Enter the Number : ");
scanf("%d",&num);

int x = ((num%2==0)?0:1);

if(x==0)
   printf("\nEven");
else
   printf("\nOdd");
}
