/* 
 * File:   main.c
 * Author: Maya
 *
 * Created on October 2, 2015, 3:45 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main ()
{
   /* local variable definition */
   char grade = 'B';

   switch(grade)
   {
   case 'A' :
      printf("Excellent!\n" );
      break;
   case 'B' :
   case 'C' :
      printf("Well done\n" );
      break;
   case 'D' :
      printf("You passed\n" );
      break;
   case 'F' :
      printf("Better try again\n" );
      break;
   default :
      printf("Invalid grade\n" );
   }
   printf("Your grade is  %c\n", grade );
 
   return 0;
}
