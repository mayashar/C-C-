

#include<stdio.h>
#include<string.h>
void strtonum();

int main()
{
    strtonum();
    return 0;
}

void strtonum()
{
    printf("string to num:\n");

    char str1[10]="16";
    char str2[10]="26.74";

    int num1;
    float num2;

    sscanf(str1,"%d",&num1);
    sscanf(str2,"%f",&num2);

    printf("num1: %d\n",num1);
    printf("num2: %f\n",num2);
}
