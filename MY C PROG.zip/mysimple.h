

extern int add(int a, int b);
extern int subtract(int a, int b);
extern int multiply(int a, int b);
