#include<stdio.h>
#include<string.h>

typedef struct student {
   char name[50];
   int marks;
}

stud;

void main() {
   stud s1;

   printf("\nEnter student record\n");

   printf("\nStudent name : ");
   scanf("%s", &s1.name);
   printf("\nEnter student marks : ");
   scanf("%d", &s1.marks);

   printf("\nStudent name is %s", s1.name);
   printf("\nTotal is %d\n\n", s1.marks);

 return 0;
}
