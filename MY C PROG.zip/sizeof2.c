#include<stdio.h>

int main() {

   printf("%d", sizeof(int));
   printf("%d", sizeof(char));
   printf("%d", sizeof(float));

   return 0;
}
