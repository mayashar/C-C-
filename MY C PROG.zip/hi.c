


#include<stdio.h>

int main()



{

    float y=9;
    float n=sin(y);
    printf("sin(y)=%.2f\n",n);
    char a;
    a='T';
    float x;
    x=8;
    printf("%.2f\n",x);
    printf("%c\n",a);
    return 0;




}
