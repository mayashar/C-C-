#include<stdio.h>

main()
{
 int roll1,roll2;
 enum standard {FIRST,SECOND,THIRD,FOURTH};
 enum standard s1,s2;



 printf("\n Enter the roll numbers for two students");
 scanf("%d%d",&roll1,&roll2);

 s1=FIRST;
 s2=FOURTH;  /*assigning the standards*/
 printf("\nThe Roll Number  %d  is in %d st Standard",roll1,s1+1);
 printf("\nThe Roll Number  %d  is in %d th Standard",roll2,s2+1);

 return 0;
}
