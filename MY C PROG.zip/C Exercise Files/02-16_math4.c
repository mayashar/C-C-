#include <stdio.h>

int main()
{
	int a;

	a = 25 / 5 * 2 + 3;
	printf("The answer is %d\n",a);

	return(0);
}

