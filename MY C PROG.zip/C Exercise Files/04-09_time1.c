#include <stdio.h>
#include <time.h>

int main()
{
	printf("The current time is %ld\n",time(NULL));

	return(0);
}

