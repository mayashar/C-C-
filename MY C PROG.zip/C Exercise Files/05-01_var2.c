#include <stdio.h>

int main()
{
	int a;

	printf("An int variable occupies %lu bytes of storage\n",sizeof(a));

	return(0);
}

