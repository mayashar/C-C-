#include <stdio.h>

int main()
{
	struct record {
		int account;
		float balance;
	};

	return(0);
}

