#include <stdio.h>

int main()
{
	char text[] = "I am a string!";

	puts(text);

	return(0);
}

