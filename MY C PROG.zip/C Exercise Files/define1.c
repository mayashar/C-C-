#include <stdio.h>

#define true 1
#define false 0


int main()
{
	printf("rank of true: %d\n",true);
	printf("rank of false: %d\n",false);
	return(0);
}
