#include <stdio.h>

int main()
{
	printf("Everyone knows that 2+2=%d\n",4);

	return(0);
}

