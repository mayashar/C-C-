#include <stdio.h>

int main()
{
	printf("This is the way the world ends");
	printf("Not with a bang but a whimper.");

	return(0);
}

