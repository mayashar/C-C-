#include <stdio.h>

int main()
{
	int pokey;

	printf("The address of `pokey` is %p\n",&pokey);

	return(0);
}

