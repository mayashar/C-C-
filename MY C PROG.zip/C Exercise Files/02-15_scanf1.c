#include <stdio.h>

int main()
{
	int x;

	printf("Type an integer: ");
	scanf("%d",&x);
	printf("Integer %d\n",x);

	return(0);
}

