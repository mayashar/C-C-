#include <stdio.h>

int main()
{
	char first[] = "I would like to go ";
	char second[] = "from here to there\n";

	return(0);
}

