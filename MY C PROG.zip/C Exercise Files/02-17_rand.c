#include <stdio.h>
#include <stdlib.h>

int main()
{
	int r;

	r = rand();

	printf("%d is a random number.\n",r);

	return(0);
}

