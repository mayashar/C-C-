#include <stdio.h>

int main()
{
	char password[] = "spatula";

	printf("The password is \"%s\"\n",password);

	return(0);
}

