#include <stdio.h>

int main()
{
	char right[] = "right";
	char left[] = "left";

	printf("%20s\n",right);
	printf("%-20s\n",left);

	return(0);
}

