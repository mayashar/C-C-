#include <stdio.h>

int main()
{
	int a;

	printf("The value of a is %d\n",a);

	return(0);
}

