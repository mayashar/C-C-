#include <stdio.h>

int *pPointer;

void SomeFunction();
{
// make pPointer point to a new integer
    pPointer = new int;
    *pPointer = 25;
}

void main()
{
    SomeFunction(); // make pPointer point to something
    printf("Value of *pPointer: %d\n", *pPointer);

    delete pPointer;
}
