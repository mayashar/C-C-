#include <stdio.h>

int main()
{
	char *string = "I'm just a normal string.\n";

	puts(string);

	return(0);
}

