#include <stdio.h>
void AddBonus(int* Sal)
{
    *Sal = *Sal + 500;
}

void main()
{


    printf("ENTER SALARY  %d\n");

    int Salary;

    scanf("%d",&Salary);

    printf("SALARY WITHOUT BONUS IS: %d\n", Salary);
    AddBonus(&Salary);
    printf("SALARY WITH BOMUS IS: %d\n", Salary);
}
