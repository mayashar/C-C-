#include <stdio.h>

int main()
{
    // Declaring/Initializing three characters pointers
    char *ptr1 = "Sunday";
    char *ptr2 = "Monday";
    char *ptr3 = "Tuesday";
    char *ptr4 = "Wednesday";
    char *ptr5 = "Thursday";
    char *ptr6 = "Friday";
    char *ptr7 = "Saturday";

    //Declaring an array of 3 char pointers
    char* arr[10];

    // Initializing the array with values
    arr[0] = ptr1;
    arr[1] = ptr2;
    arr[2] = ptr3;
    arr[3] = ptr4;
    arr[4] = ptr5;
    arr[5] = ptr6;
    arr[6] = ptr7;

    //Printing the values stored in array
    printf("\n %s\n", arr[0]);
    printf("\n %s\n", arr[1]);
    printf("\n %s\n", arr[2]);
    printf("\n %s\n", arr[3]);
    printf("\n %s\n", arr[4]);
    printf("\n %s\n", arr[5]);
    printf("\n %s\n", arr[6]);


    return 0;
}
