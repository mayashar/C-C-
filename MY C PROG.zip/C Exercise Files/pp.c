#include <stdio.h>

void AddFive(int Number)
{
    Number = Number + 5;
}

void main()
{
    int nMyNumber = 18;

    printf("My original number is %d\n", nMyNumber);
    AddFive(nMyNumber);
    printf("My new number is %d\n", nMyNumber);
}
