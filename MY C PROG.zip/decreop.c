#include<stdio.h>

void main()
{
int a,b;

a = 5;
b = 5;

printf("Value of a : %d",a--);
printf("\nValue of b : %d",--b);
}
