

#include<stdio.h>

void myname()
{
    printf("maya sharma\n");
}

int main()

{

   myname();



    return 0;
}
