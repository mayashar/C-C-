#include<stdio.h>

int main()
{
typedef int Marks;
Marks math = 40, sci = 20, eng=45;

printf("Marks in maths : %d",math);
printf("\nMarks in science : %d",sci);
printf("\nMarks in english : %d\n\n",eng);
return(0);
}
