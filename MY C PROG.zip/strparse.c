

#include<stdio.h>
#include<string.h>

void strparse();

int main()
{
    strparse();
    return 0;
}
void strparse()
{
    char cities[80]="new york,seoul,ktm,charlotte";
    char token[2]=",";
    char* city;

    printf("cities: %s\n",cities);

    city=strtok(cities,token);

    while(city!=NULL)
    {
        printf("%s\n",city);
        city=strtok(NULL,token);
    }
}
