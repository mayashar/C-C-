//Temperature Conversion:
              
#include<stdio.h>

#define freezintpt 32.0f
#define scale (5.0f/9.0f)

int main(void)
{
    float F,C;
    printf("Enter Farenheit Temperature: ");
    scanf("%f", &F);
    
    C=(F-freezintpt)*scale;
    printf("Celcius is: %f\n",C);
    
    getch();
    
    
    
    }
