//A Simple Calculator

#include<stdio.h>
#include<conio.h>

int main(void)
{
    int a,b,sum,sub,mul,div,mod;
    
    printf("Enter First Number:\a");
    scanf("%d", &a);
    printf("Enter Second Number:\a");
    scanf("%d", &b);
    
    sum=a+b;
    sub=a-b;
    mul=a*b;
    div=a/b;
    mod=a%b;
    

    printf("The sum is %d \n",sum);
    printf("The sub is %d \n",sub);
    printf("The mul is %d \n",mul);
    printf("The div is %d\n",div);
    printf("The mod is %d",mod);
    
    
    getch();
    
    }

