#include<stdio.h>
#include<conio.h>

int main(void)
{
    int x, y;
    x=6;
    y=9;
    int sum= x+y;
    


    printf("The sum is: %d", sum);
    
    getch();
    
    }

